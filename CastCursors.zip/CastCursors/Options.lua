-- CastCursors Options.lua

local ADDON_NAME = "CastCursors"
local CR = LibStub("AceAddon-3.0"):GetAddon(ADDON_NAME)

------------------------------------------------------------------------
-- Safe profile accessor — never errors if db isn't ready yet
------------------------------------------------------------------------
local function P()
    return CR.db and CR.db.profile or {}
end

local function get(info)      return P()[info[#info]] end
local function set(info, val) P()[info[#info]] = val ; if CR.db then CR:RefreshDB() end end

local function getColor(info)
    local c = P()[info[#info]]
    if not c then return 1,1,1,1 end
    return c.r, c.g, c.b, 1
end
local function setColor(info, r, g, b)
    local c = P()[info[#info]]
    if c then c.r,c.g,c.b = r,g,b ; if CR.db then CR:RefreshDB() end end
end

------------------------------------------------------------------------
-- Dropdown value tables
------------------------------------------------------------------------
local castModeValues = {
    sweep  = "Sweep – clockwise/CCW drain",
    shrink = "Shrink – ring collapses inward",
    expand = "Expand – ring grows outward",
    pulse  = "Pulse – faster near completion",
    glow   = "Glow Pulse – outer glow throbs",
    none   = "None – ring stays constant",
}
local colorSourceValues = {
    custom   = "Custom solid color",
    school   = "Spell school color",
    gradient = "Custom gradient",
}
local gradOrientValues = {
    HORIZONTAL = "Horizontal (left → right)",
    VERTICAL   = "Vertical (bottom → top)",
}
local sparkleTypeValues = {
    dot      = "Simple dot",
    autocast = "AutoCast shine (Blizzard spinning dots)",
    proc     = "Proc glow (Blizzard spell alert shimmer)",
}
local sparkleDirValues = {
    cw  = "Clockwise",
    ccw = "Counter-clockwise",
}

------------------------------------------------------------------------
-- Nil-safe helper predicates
------------------------------------------------------------------------
local function colorIs(v)  return function() return P().colorSource == v end end
local function notColor(v) return function() return P().colorSource ~= v end end

local function sweepOff()
    local p = P()
    return p.castMode ~= "sweep" and p.chanMode ~= "sweep"
end
local function noGlow()    return not P().showGlow     end
local function noLabel()   return not P().showCastText end
local function noSparkle() return not P().showSparkle  end
local function notDot()
    local p = P()
    return not p.showSparkle or p.sparkleType ~= "dot"
end
local function noFlash()   return not P().flashOnComplete end

------------------------------------------------------------------------
-- Options table
------------------------------------------------------------------------
local options = {
    name = "Cast Cursors", handler = CR, type = "group",
    args = {

        -- ── General ───────────────────────────────────────────────────
        hGen     = { order=1,  type="header", name="General" },
        enabled  = { order=2,  type="toggle", name="Enable Cast Cursors",
                     get=get,  set=set },
        updateHz = { order=3,  type="range",  name="Update rate (sec)",
                     min=0.01, max=0.10, step=0.01, get=get, set=set },

        -- ── Ring ─────────────────────────────────────────────────────
        hRing     = { order=10, type="header", name="Ring" },
        ringSize  = { order=11, type="range", name="Size",
                      desc="Diameter at rest (px).",
                      min=16, max=200, step=2, get=get, set=set },
        ringAlpha = { order=12, type="range", name="Opacity",
                      min=0, max=1, step=0.05, isPercent=true,
                      get=get, set=set },

        -- ── Glow ─────────────────────────────────────────────────────
        hGlow     = { order=20, type="header", name="Outer Glow" },
        showGlow  = { order=21, type="toggle", name="Show glow",
                      get=get, set=set },
        glowAlpha = { order=22, type="range", name="Glow opacity",
                      min=0, max=1, step=0.05, isPercent=true,
                      get=get, set=set, disabled=noGlow },

        -- ── Colors ────────────────────────────────────────────────────
        hColor      = { order=30, type="header", name="Colors" },
        colorSource = { order=31, type="select", name="Color mode",
                        values=colorSourceValues, get=get, set=set },
        idleColor   = { order=32, type="color", name="Idle color",
                        hasAlpha=false, get=getColor, set=setColor },
        castColor   = { order=33, type="color", name="Cast color",
                        desc="Used in Custom mode, or as fallback.",
                        hasAlpha=false, get=getColor, set=setColor,
                        hidden=notColor("custom") },
        chanColor   = { order=34, type="color", name="Channel color",
                        hasAlpha=false, get=getColor, set=setColor,
                        hidden=notColor("custom") },
        schoolNote  = {
            order=35, type="description", fontSize="small",
            name="|cffff8040Fire|r  |cff80ff80Nature|r  |cff80ccffFrost|r"
              .. "  |cff9966ffShadow|r  |cffcc88ffArcane|r"
              .. "  |cffffff88Holy|r  |cffccaa88Physical|r\n\n"
              .. "Ring color follows the school of the spell being cast.",
            hidden=notColor("school"),
        },

        -- ── Gradient ─────────────────────────────────────────────────
        hGrad               = { order=40, type="header", name="Gradient",
                                 hidden=notColor("gradient") },
        gradientOrientation = { order=41, type="select", name="Orientation",
                                 values=gradOrientValues, get=get, set=set,
                                 hidden=notColor("gradient") },
        gradientStartColor  = { order=42, type="color", name="Start color",
                                 hasAlpha=false, get=getColor, set=setColor,
                                 hidden=notColor("gradient") },
        gradientEndColor    = { order=43, type="color", name="End color",
                                 hasAlpha=false, get=getColor, set=setColor,
                                 hidden=notColor("gradient") },
        gradientAnimate     = { order=44, type="toggle",
                                 name="Animate (colors shift over cast)",
                                 get=get, set=set,
                                 hidden=notColor("gradient") },

        -- ── Cast Animation ────────────────────────────────────────────
        hAnim    = { order=50, type="header", name="Cast Animation" },
        castMode = { order=51, type="select", name="Cast mode",
                     values=castModeValues, get=get, set=set },
        chanMode = { order=52, type="select", name="Channel mode",
                     values=castModeValues, get=get, set=set },
        sweepCW  = { order=53, type="toggle",
                     name="Clockwise drain (Sweep mode only)",
                     get=get, set=set, disabled=sweepOff },

        -- ── Flash ─────────────────────────────────────────────────────
        hFlash          = { order=60, type="header", name="Completion Flash" },
        flashOnComplete = { order=61, type="toggle", name="Flash on complete",
                            get=get, set=set },
        flashDuration   = { order=62, type="range", name="Duration (sec)",
                            min=0.05, max=1.0, step=0.05,
                            get=get, set=set, disabled=noFlash },

        -- ── Sparkle ───────────────────────────────────────────────────
        hSparkle    = { order=70, type="header", name="Sparkle" },
        showSparkle = { order=71, type="toggle", name="Show sparkle",
                        get=get, set=set },
        sparkleType = {
            order=72, type="select", name="Sparkle type",
            desc="Dot: simple glowing point.\n"
              .. "AutoCast Shine: Blizzard spinning dots (pet autocast style).\n"
              .. "Proc Glow: Blizzard spell-proc shimmer.",
            values=sparkleTypeValues, get=get, set=set, disabled=noSparkle,
        },
        sparkleDir   = { order=73, type="select", name="Direction",
                         values=sparkleDirValues, get=get, set=set,
                         disabled=noSparkle },
        sparkleSpeed = { order=74, type="range",  name="Speed (rad/sec)",
                         min=0.2, max=10.0, step=0.1,
                         get=get, set=set, disabled=noSparkle },
        sparkleCount = {
            order=75, type="range", name="Count (dot mode)",
            desc="Number of dots orbiting simultaneously.",
            min=1, max=4, step=1,
            get=get, set=set, disabled=notDot,
        },
        sparkleSize  = { order=76, type="range", name="Size (px)",
                         min=4, max=64, step=2,
                         get=get, set=set, disabled=noSparkle },

        -- ── Spell Label ───────────────────────────────────────────────
        hLabel       = { order=80, type="header", name="Spell Name Label" },
        showCastText = { order=81, type="toggle", name="Show spell name",
                         get=get, set=set },
        castTextFont = {
            order=82, type="select", dialogControl="LSM30_Font", name="Font",
            values=function() return CR:GetFontValues() end,
            get=get, set=set, disabled=noLabel,
        },
        castTextSize  = { order=83, type="range", name="Font size",
                          min=8, max=28, step=1,
                          get=get, set=set, disabled=noLabel },
        castTextColor = { order=84, type="color", name="Label color",
                          hasAlpha=false, get=getColor, set=setColor,
                          disabled=noLabel },

        -- ── Profiles ─────────────────────────────────────────────────
        hProf    = { order=99,  type="header",      name="Profiles" },
        profNote = { order=100, type="description",
                     name="Use the Profiles tab for per-character settings." },
    },
}

------------------------------------------------------------------------
-- Register with AceConfig + Blizzard Settings panel
------------------------------------------------------------------------
function CR:SetupOptions()
    local AC  = LibStub("AceConfig-3.0")
    local ACD = LibStub("AceConfigDialog-3.0")
    AC:RegisterOptionsTable(ADDON_NAME, options)
    self.optionsFrame = ACD:AddToBlizOptions(ADDON_NAME, "Cast Cursors")
    local po = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
    AC:RegisterOptionsTable(ADDON_NAME .. "_Profiles", po)
    ACD:AddToBlizOptions(ADDON_NAME .. "_Profiles", "Profiles", "Cast Cursors")
end

-- OnEnable fires after OnInitialize (and thus after BuildFrames).
-- This file loads last so this is the only OnEnable definition.
function CR:OnEnable()
    -- Sync the local db upvalue in Core.lua via RefreshDB
    if self.db then CR:RefreshDB() end
    self:SetupOptions()
end
