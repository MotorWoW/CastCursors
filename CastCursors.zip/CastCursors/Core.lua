-- CastCursors Core.lua
-- Config.lua MUST load before this file (see CastCursors.toc).

local ADDON_NAME = "CastCursors"
-- NewAddon is safe here because Config.lua has already run and registered
-- CR.defaults on the table that AceAddon will hand back to us.
local CR = LibStub("AceAddon-3.0"):NewAddon(ADDON_NAME, "AceConsole-3.0", "AceEvent-3.0")

-- Copy data from Config.lua's namespace table onto the AceAddon object.
-- Config.lua uses CastCursorsNS because AceAddon didn't exist when it loaded.
do
    local ns = CastCursorsNS or {}
    CR.defaults       = ns.defaults
    CR.schoolColors   = ns.schoolColors
    CR.schoolPriority = ns.schoolPriority
    CR.GetSchoolColor = ns.GetSchoolColor
    CR.GetLSM         = ns.GetLSM
    CR.ResolveFont    = ns.ResolveFont
    CR.GetFontValues  = ns.GetFontValues
    CastCursorsNS = nil  -- clean up global
end

------------------------------------------------------------------------
-- Upvalues
------------------------------------------------------------------------
local GetCursorPosition = GetCursorPosition
local UnitCastingInfo   = UnitCastingInfo
local UnitChannelInfo   = UnitChannelInfo
local GetTime           = GetTime
local math_cos          = math.cos
local math_sin          = math.sin
local math_min          = math.min
local math_max          = math.max
local math_pi           = math.pi
local twoPi             = math_pi * 2

------------------------------------------------------------------------
-- Module-level locals (declared before any function that closes over them)
------------------------------------------------------------------------
local db
local masterFrame
local ringClip, flashClip     -- clip frames (set in BuildFrames)
local ringShape
local flashShape
local glow, castLabel
local sweepCD
local sweepActive  = false
local sweepReverse = false
local sparkDots    = {}
local autocasts    = {}
local procGlow     = nil
local sparkAngle   = 0
local elapsed_accum = 0
local flashTimer   = 0
local flashing     = false
local lastSpellName = nil

-- Blizzard template availability flags — set true initially,
-- flipped to false if CreateFrame pcall fails during BuildFrames.
local HAS_AUTOCAST_TEMPLATE = true
local HAS_PROC_TEMPLATE     = true

------------------------------------------------------------------------
-- Cast info
------------------------------------------------------------------------
local function GetCastInfo()
    local name,_,_,s,e,_,_,_,id = UnitCastingInfo("player")
    if name then
        local now = GetTime()*1000
        return math_min(math_max((now-s)/(e-s),0),1), "cast", name, id, s, e
    end
    name,_,_,s,e,_,_,id = UnitChannelInfo("player")
    if name then
        local now = GetTime()*1000
        return math_min(math_max((e-now)/(e-s),0),1), "channel", name, id, s, e
    end
    return nil, nil, nil, nil, nil, nil
end

------------------------------------------------------------------------
-- Spell school cache
-- C_Spell.GetSpellInfo does not expose schoolMask.
-- C_Spell.GetSpellSchools(spellId) returns a table of school name strings
-- e.g. {"Nature"} or {"Fire","Arcane"}.  We map names to bitmasks.
------------------------------------------------------------------------
local SCHOOL_NAME_TO_MASK = {
    Physical = 1, Holy = 2, Fire = 4, Nature = 8,
    Frost = 16, Shadow = 32, Arcane = 64,
}

local function GetSpellSchoolMask(spellId)
    if not spellId then return nil end
    -- Try C_Spell.GetSpellSchools (retail 11.0+)
    if C_Spell and C_Spell.GetSpellSchools then
        local schools = C_Spell.GetSpellSchools(spellId)
        if schools and #schools > 0 then
            local mask = 0
            for _, name in ipairs(schools) do
                mask = mask + (SCHOOL_NAME_TO_MASK[name] or 0)
            end
            if mask > 0 then return mask end
        end
    end
    return nil
end

------------------------------------------------------------------------
-- Color helpers
------------------------------------------------------------------------
local function ResolveColor(mode, spellId, progress)
    local src = db.colorSource
    if src == "school" and spellId then
        local mask = GetSpellSchoolMask(spellId)
        if mask then
            local c = CR:GetSchoolColor(mask)
            if c then return c.r, c.g, c.b, nil, nil end
        end
    end
    if src == "gradient" then
        local sc, ec = db.gradientStartColor, db.gradientEndColor
        if db.gradientAnimate and progress then
            local t = progress
            return nil, nil, nil,
                { r=sc.r+(ec.r-sc.r)*t, g=sc.g+(ec.g-sc.g)*t, b=sc.b+(ec.b-sc.b)*t },
                { r=ec.r+(sc.r-ec.r)*t, g=ec.g+(sc.g-ec.g)*t, b=ec.b+(sc.b-ec.b)*t }
        end
        return nil, nil, nil, sc, ec
    end
    local c = (mode=="cast")    and db.castColor
           or (mode=="channel") and db.chanColor
           or db.idleColor
    return c.r, c.g, c.b, nil, nil
end

local function ApplyColor(tex, r, g, b, gs, ge, alpha)
    if gs and ge then
        tex:SetGradient(db.gradientOrientation,
            CreateColor(gs.r,gs.g,gs.b,1),
            CreateColor(ge.r,ge.g,ge.b,1))
        tex:SetVertexColor(1,1,1,alpha)
    else
        -- Reset any previous gradient to solid
        tex:SetGradient("HORIZONTAL", CreateColor(r,g,b,1), CreateColor(r,g,b,1))
        tex:SetVertexColor(r,g,b,alpha)
    end
end

local function MidColor(gs, ge, r, g, b)
    if gs and ge then
        return (gs.r+ge.r)*.5, (gs.g+ge.g)*.5, (gs.b+ge.b)*.5
    end
    return r, g, b
end

------------------------------------------------------------------------
-- Ring layer construction
-- Simple: just ringShape (ring.tga) and flashShape for completion flash.
-- Fill texture feature removed — the plain ring works cleanly with all
-- color/gradient options and doesn't need LSM texture support.
------------------------------------------------------------------------
local function BuildRingLayers(parent)
    local clip = CreateFrame("Frame", nil, parent)
    clip:SetFrameLevel(parent:GetFrameLevel()+1)

    ringShape = clip:CreateTexture(nil, "OVERLAY")
    ringShape:SetTexture("Interface\\AddOns\\CastCursors\\ring")
    ringShape:SetAllPoints(clip)
    ringShape:SetBlendMode("ADD")
    ringShape:Show()

    local fclip = CreateFrame("Frame", nil, parent)
    fclip:SetFrameLevel(parent:GetFrameLevel()+1)
    fclip:Hide()

    flashShape = fclip:CreateTexture(nil, "OVERLAY")
    flashShape:SetTexture("Interface\\AddOns\\CastCursors\\ring")
    flashShape:SetAllPoints(fclip)
    flashShape:SetBlendMode("ADD")
    flashShape:Show()

    return clip, fclip
end

function CR:RefreshTexture()
    -- No-op: fill texture feature removed. Kept so callers don't error.
end

------------------------------------------------------------------------
-- Sparkle — plain dot
------------------------------------------------------------------------
local MAX_DOTS = 4

local function BuildDots(parent)
    for i = 1, MAX_DOTS do
        local d = parent:CreateTexture(nil, "OVERLAY")
        d:SetTexture("Interface\\AddOns\\CastCursors\\spark")
        d:SetBlendMode("ADD")
        d:SetSize(8,8)
        d:Hide()
        sparkDots[i] = d
    end
end

local function UpdateDots(cx, cy, size, r, g, b, alpha, dt)
    local count  = math_min(db.sparkleCount or 1, MAX_DOTS)
    local dir    = (db.sparkleDir == "cw") and -1 or 1
    sparkAngle   = (sparkAngle + dt * (db.sparkleSpeed or 2.5) * dir) % twoPi
    local radius = size * 0.5
    local sep    = twoPi / count
    for i = 1, MAX_DOTS do
        local d = sparkDots[i]
        if i <= count then
            local a = sparkAngle + (i-1)*sep
            local sz = db.sparkleSize or 8
            d:SetSize(sz, sz)
            d:ClearAllPoints()
            d:SetPoint("CENTER", UIParent, "BOTTOMLEFT",
                cx + radius*math_cos(a), cy + radius*math_sin(a))
            d:SetVertexColor(r, g, b, math_min(alpha+0.1, 1))
            d:Show()
        else
            d:Hide()
        end
    end
end

local function HideDots()
    for _, d in ipairs(sparkDots) do d:Hide() end
end

------------------------------------------------------------------------
-- Sparkle — AutoCastShine (Blizzard spinning dots)
------------------------------------------------------------------------
local MAX_AUTOCASTS = 4

local function BuildAutocasts(parent)
    if not HAS_AUTOCAST_TEMPLATE then return end
    for i = 1, MAX_AUTOCASTS do
        local ok, f = pcall(CreateFrame, "Frame", nil, parent, "AutoCastShineTemplate")
        if ok and f then
            f:SetSize(24,24)
            f:Hide()
            autocasts[i] = f
        else
            HAS_AUTOCAST_TEMPLATE = false
            break
        end
    end
end

local function UpdateAutocasts(cx, cy, size, dt)
    if not HAS_AUTOCAST_TEMPLATE then return end
    local count  = math_min(db.sparkleCount or 1, MAX_AUTOCASTS)
    local dir    = (db.sparkleDir == "cw") and -1 or 1
    sparkAngle   = (sparkAngle + dt * (db.sparkleSpeed or 2.5) * dir) % twoPi
    local radius = size * 0.5 + 4
    local sep    = twoPi / count
    for i = 1, MAX_AUTOCASTS do
        local f = autocasts[i]
        if not f then break end
        if i <= count then
            local sz = db.sparkleSize or 24
            f:SetSize(sz, sz)
            f:ClearAllPoints()
            f:SetPoint("CENTER", UIParent, "BOTTOMLEFT",
                cx + radius*math_cos(sparkAngle+(i-1)*sep),
                cy + radius*math_sin(sparkAngle+(i-1)*sep))
            if not f:IsShown() then
                f:Show()
                if AutoCastShine_AutoCastStart then
                    pcall(AutoCastShine_AutoCastStart, f)
                end
            end
        else
            if f:IsShown() then
                if AutoCastShine_AutoCastStop then
                    pcall(AutoCastShine_AutoCastStop, f)
                end
                f:Hide()
            end
        end
    end
end

local function HideAutocasts()
    for _, f in ipairs(autocasts) do
        if f:IsShown() then
            if AutoCastShine_AutoCastStop then pcall(AutoCastShine_AutoCastStop, f) end
            f:Hide()
        end
    end
end

------------------------------------------------------------------------
-- Sparkle — Proc glow
------------------------------------------------------------------------
local function BuildProcGlow(parent)
    if not HAS_PROC_TEMPLATE then return end
    local ok, f = pcall(CreateFrame, "Frame", nil, parent,
                        "ActionButtonSpellAlertTemplate")
    if ok and f then
        f:SetSize(40,40)
        f:Hide()
        procGlow = f
    else
        HAS_PROC_TEMPLATE = false
    end
end

local function UpdateProcGlow(cx, cy, size, dt)
    if not procGlow then return end
    local dir   = (db.sparkleDir == "cw") and -1 or 1
    sparkAngle  = (sparkAngle + dt * (db.sparkleSpeed or 2.5) * dir) % twoPi
    local radius = size * 0.5
    local gsize  = (db.sparkleSize or 40) * 1.5
    procGlow:SetSize(gsize, gsize)
    procGlow:ClearAllPoints()
    procGlow:SetPoint("CENTER", UIParent, "BOTTOMLEFT",
        cx + radius*math_cos(sparkAngle),
        cy + radius*math_sin(sparkAngle))
    if not procGlow:IsShown() then
        procGlow:Show()
        if procGlow.ProcStartAnim then
            pcall(function() procGlow.ProcStartAnim:Play() end)
        end
    end
end

local function HideProcGlow()
    if procGlow and procGlow:IsShown() then
        if procGlow.ProcStartAnim then
            pcall(function() procGlow.ProcStartAnim:Stop() end)
        end
        procGlow:Hide()
    end
end

local function HideAllSparkles()
    HideDots() ; HideAutocasts() ; HideProcGlow()
end

------------------------------------------------------------------------
-- Sweep (native Cooldown widget)
------------------------------------------------------------------------
local function InitSweep()
    sweepCD = CreateFrame("Cooldown", "CastCursorsSweep", masterFrame,
                          "CooldownFrameTemplate")
    sweepCD:SetFrameLevel(masterFrame:GetFrameLevel()+2)
    sweepCD:SetHideCountdownNumbers(true)
    sweepCD:SetDrawEdge(true)
    sweepCD:SetUseCircularEdge(true)
    sweepCD:SetSwipeTexture("Interface\\AddOns\\CastCursors\\ring")
    sweepCD:Hide()
end

local function StartSweep(cx, cy, size, r, g, b, gs, ge, sMS, eMS)
    local dur   = (eMS-sMS)/1000
    local start = sMS/1000
    local wantRev = not db.sweepCW
    if sweepReverse ~= wantRev then
        sweepCD:SetReverse(wantRev) ; sweepReverse = wantRev
    end
    local sr, sg_, sb_ = MidColor(gs, ge, r, g, b)
    sweepCD:SetSwipeColor(sr, sg_, sb_, db.ringAlpha)
    sweepCD:SetSize(size, size)
    sweepCD:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, cy)
    sweepCD:SetCooldown(start, dur)
    sweepCD:Show()
    sweepActive = true
end

local function StopSweep()
    if sweepActive then
        sweepCD:Clear() ; sweepCD:Hide() ; sweepActive = false
    end
end

------------------------------------------------------------------------
-- BuildFrames (called from OnInitialize)
------------------------------------------------------------------------
local function BuildFrames()
    masterFrame = CreateFrame("Frame", "CastCursorsMasterFrame", UIParent)
    masterFrame:SetAllPoints(UIParent)
    masterFrame:SetFrameStrata("TOOLTIP")
    masterFrame:SetFrameLevel(128)

    ringClip, flashClip = BuildRingLayers(masterFrame)

    glow = masterFrame:CreateTexture(nil, "OVERLAY")
    glow:SetTexture("Interface\\AddOns\\CastCursors\\ring")
    glow:SetBlendMode("ADD")
    glow:Hide()

    castLabel = masterFrame:CreateFontString(nil, "OVERLAY")
    castLabel:SetFont(CR:ResolveFont(db.castTextFont), db.castTextSize)
    castLabel:Hide()

    BuildDots(masterFrame)
    BuildAutocasts(masterFrame)
    BuildProcGlow(masterFrame)
    InitSweep()

    CR:RefreshTexture()
end

------------------------------------------------------------------------
-- OnUpdate
------------------------------------------------------------------------
function CR:OnUpdate(elapsed)
    elapsed_accum = elapsed_accum + elapsed
    if elapsed_accum < db.updateHz then return end
    local dt = elapsed_accum ; elapsed_accum = 0

    if not db.enabled then
        ringClip:Hide() ; glow:Hide() ; castLabel:Hide() ; flashClip:Hide()
        HideAllSparkles() ; StopSweep()
        return
    end

    local uiScale = UIParent:GetEffectiveScale()
    local cx, cy  = GetCursorPosition()
    cx = cx/uiScale ; cy = cy/uiScale

    local progress, mode, spellName, spellId, sMS, eMS = GetCastInfo()
    local casting    = mode ~= nil
    local baseSize   = db.ringSize
    local curSize    = baseSize
    local activeMode = casting and ((mode=="cast") and db.castMode or db.chanMode) or "none"

    local r, g, b, gs, ge = ResolveColor(mode or "idle", spellId, progress)
    if not casting then
        r, g, b = db.idleColor.r, db.idleColor.g, db.idleColor.b
        gs, ge  = nil, nil
    end

    -- Size transform
    if casting then
        if     activeMode == "shrink" then curSize = baseSize*(1 - progress*0.65)
        elseif activeMode == "expand" then curSize = baseSize*(1 + progress*0.5)
        elseif activeMode == "pulse"  then
            curSize = baseSize*(0.85 + 0.15*math_sin(GetTime()*twoPi*(1+progress*4)))
        end
    end

    -- Completion flash
    if not casting and lastSpellName and db.flashOnComplete then
        flashing = true ; flashTimer = db.flashDuration
    end
    lastSpellName = spellName

    if flashing then
        flashTimer = flashTimer - dt
        if flashTimer <= 0 then
            flashing = false ; flashClip:Hide()
        else
            local fa = (flashTimer/db.flashDuration)*0.9
            flashClip:SetSize(baseSize*1.7, baseSize*1.7)
            flashClip:ClearAllPoints()
            flashClip:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, cy)
            ApplyColor(flashShape, r or 1, g or 1, b or 1, gs, ge, fa)
            flashClip:Show()
        end
    end

    -- Sweep vs normal ring
    if casting and activeMode == "sweep" and sMS then
        StartSweep(cx, cy, curSize, r, g, b, gs, ge, sMS, eMS)
        ringClip:Hide()
    else
        StopSweep()
        ringClip:SetSize(curSize, curSize)
        ringClip:ClearAllPoints()
        ringClip:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, cy)
        ApplyColor(ringShape, r or 1, g or 1, b or 1, gs, ge, db.ringAlpha)
        ringClip:Show()
    end

    if sweepActive then
        sweepCD:ClearAllPoints()
        sweepCD:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, cy)
    end

    -- Glow
    if db.showGlow then
        local ga = db.glowAlpha
        if casting and activeMode == "glow" then
            ga = ga*(0.5 + 0.5*math_sin(GetTime()*twoPi*(1+progress*3)+math_pi))
        end
        glow:SetSize(curSize*1.45, curSize*1.45)
        glow:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, cy)
        local mr, mg, mb = MidColor(gs, ge, r or 1, g or 1, b or 1)
        glow:SetVertexColor(mr, mg, mb, ga)
        glow:Show()
    else
        glow:Hide()
    end

    -- Sparkle
    if db.showSparkle then
        local st = db.sparkleType or "dot"
        if st ~= "dot"      then HideDots()      end
        if st ~= "autocast" then HideAutocasts()  end
        if st ~= "proc"     then HideProcGlow()   end
        local sr_, sg_, sb_ = MidColor(gs, ge, r or 1, g or 1, b or 1)
        if     st == "dot"      then UpdateDots(cx, cy, curSize, sr_, sg_, sb_, db.ringAlpha, dt)
        elseif st == "autocast" then UpdateAutocasts(cx, cy, curSize, dt)
        elseif st == "proc"     then UpdateProcGlow(cx, cy, curSize, dt)
        end
    else
        HideAllSparkles()
    end

    -- Cast label
    if db.showCastText and spellName then
        castLabel:SetFont(CR:ResolveFont(db.castTextFont), db.castTextSize)
        castLabel:SetTextColor(db.castTextColor.r, db.castTextColor.g, db.castTextColor.b)
        castLabel:SetText(spellName)
        castLabel:ClearAllPoints()
        castLabel:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, cy+curSize*0.5+14)
        castLabel:Show()
    else
        castLabel:Hide()
    end
end

------------------------------------------------------------------------
-- Addon lifecycle
-- NOTE: Options.lua defines SetupOptions() and calls it from its own
-- OnEnable hook, so we only handle core init here.
------------------------------------------------------------------------
local updateFrame

function CR:OnInitialize()
    -- self.defaults was populated by Config.lua which loaded first
    self.db = LibStub("AceDB-3.0"):New("CastCursorsDB", self.defaults, true)
    db = self.db.profile
    self:GetLSM()   -- defined in Config.lua
    BuildFrames()
    updateFrame = CreateFrame("Frame")
    updateFrame:SetScript("OnUpdate", function(_, e) CR:OnUpdate(e) end)
    self:RegisterChatCommand("cc",          "OpenOptions")
    self:RegisterChatCommand("castcursors", "OpenOptions")
    self:Print("|cff00ccffCast Cursors|r loaded. Type /cc to configure.")
end

-- OnEnable defined in Options.lua (loads last, handles db sync + SetupOptions)

function CR:OnDisable()
    if ringClip  then ringClip:Hide()  end
    if glow      then glow:Hide()      end
    if castLabel then castLabel:Hide() end
    if flashClip then flashClip:Hide() end
    HideAllSparkles() ; StopSweep()
end

function CR:RefreshDB()
    db = self.db.profile
    if castLabel then
        castLabel:SetFont(self:ResolveFont(db.castTextFont), db.castTextSize)
    end
    self:RefreshTexture()
end

function CR:OpenOptions()
    LibStub("AceConfigDialog-3.0"):Open(ADDON_NAME)
end
