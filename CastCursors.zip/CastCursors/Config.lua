-- CastCursors Config.lua
-- Loads before Core.lua. Writes to CastCursorsNS; Core.lua copies onto CR.

local ADDON_NAME = "CastCursors"
CastCursorsNS = CastCursorsNS or {}
local CR = CastCursorsNS

------------------------------------------------------------------------
-- Defaults
------------------------------------------------------------------------
CR.defaults = {
    profile = {
        enabled   = true,
        updateHz  = 0.02,

        ringSize  = 64,
        ringAlpha = 0.85,

        showGlow  = true,
        glowAlpha = 0.40,

        colorSource         = "custom",
        idleColor           = { r=1.0, g=1.0, b=1.0 },
        castColor           = { r=0.4, g=0.7, b=1.0 },
        chanColor           = { r=0.6, g=0.3, b=1.0 },

        gradientOrientation = "HORIZONTAL",
        gradientStartColor  = { r=0.0, g=0.5, b=1.0 },
        gradientEndColor    = { r=1.0, g=0.0, b=0.8 },
        gradientAnimate     = false,

        castMode  = "sweep",
        chanMode  = "sweep",
        sweepCW   = true,

        showSparkle  = true,
        sparkleType  = "dot",
        sparkleDir   = "cw",
        sparkleSpeed = 2.5,
        sparkleCount = 1,
        sparkleSize  = 8,

        showCastText  = false,
        castTextSize  = 12,
        castTextFont  = "Friz Quadrata TT",
        castTextColor = { r=1.0, g=1.0, b=1.0 },

        flashOnComplete = true,
        flashDuration   = 0.25,
    },
}

------------------------------------------------------------------------
-- Spell school colors
------------------------------------------------------------------------
CR.schoolColors = {
    [1]  = { r=1.00, g=0.90, b=0.70 },  -- Physical
    [2]  = { r=1.00, g=0.90, b=0.50 },  -- Holy
    [4]  = { r=1.00, g=0.40, b=0.10 },  -- Fire
    [8]  = { r=0.30, g=1.00, b=0.30 },  -- Nature
    [16] = { r=0.50, g=0.80, b=1.00 },  -- Frost
    [32] = { r=0.60, g=0.20, b=1.00 },  -- Shadow
    [64] = { r=0.80, g=0.50, b=1.00 },  -- Arcane
}
CR.schoolPriority = { 4, 16, 32, 64, 8, 2, 1 }

function CR:GetSchoolColor(mask)
    if not mask then return nil end
    for _, m in ipairs(self.schoolPriority) do
        if bit.band(mask, m) > 0 then return self.schoolColors[m] end
    end
end

------------------------------------------------------------------------
-- LSM helpers
------------------------------------------------------------------------
local LSM

function CR:GetLSM()
    if not LSM then LSM = LibStub("LibSharedMedia-3.0", true) end
    return LSM
end

function CR:ResolveFont(key)
    local lsm = self:GetLSM()
    if lsm then
        local p = lsm:Fetch("font", key)
        if p then return p end
    end
    local b = {
        ["Friz Quadrata TT"] = "Fonts\\FRIZQT__.TTF",
        ["Morpheus"]         = "Fonts\\MORPHEUS.TTF",
        ["Skurri"]           = "Fonts\\SKURRI.TTF",
        ["Arial Narrow"]     = "Fonts\\ARIALN.TTF",
        ["Nimrod MT"]        = "Fonts\\NIM_____.TTF",
    }
    return b[key] or "Fonts\\FRIZQT__.TTF"
end

function CR:GetFontValues()
    local lsm = self:GetLSM()
    local t, seen = {}, {}
    local builtins = {
        "Friz Quadrata TT", "Morpheus", "Skurri", "Arial Narrow", "Nimrod MT",
    }
    for _, n in ipairs(builtins) do
        if not seen[n] then t[n] = n ; seen[n] = true end
    end
    if lsm then
        local ft = lsm:HashTable("font")
        local extras = {}
        for k in pairs(ft) do
            if not seen[k] then extras[#extras+1] = k ; seen[k] = true end
        end
        table.sort(extras)
        for _, n in ipairs(extras) do t[n] = n end
    end
    return t
end
